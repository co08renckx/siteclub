<?php 

session_start ();

$_SESSION['type'] = $_GET['type'];



?>