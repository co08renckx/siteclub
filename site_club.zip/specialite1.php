<?php 

session_start ();

$_SESSION['specialite'] = $_GET['specialite'];



?>