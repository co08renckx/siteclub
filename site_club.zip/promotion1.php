<?php 

session_start ();

$_SESSION['promotion'] = $_GET['promotion'];



?>