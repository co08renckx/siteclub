<?php

Class gestionnaire {
	Public $id_gestionnaire;
	Public $Nom;
	Public $Email;
	Public $Password;
}






 ?>